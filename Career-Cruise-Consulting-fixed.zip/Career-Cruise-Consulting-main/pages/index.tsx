import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import HomePage from "../components/Home/HomePage";

export default function Home() {
  return (
    <>
      <ToastContainer />
      <HomePage />
    </>
  );
}
